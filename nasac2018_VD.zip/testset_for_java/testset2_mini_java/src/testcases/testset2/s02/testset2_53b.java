package testcases.testset2.s02;
import testcasesupport.*;

import javax.servlet.http.*;

public class testset2_53b
{
    public void foo_barSink(String data , HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        (new testset2_53c()).foo_barSink(data , request, response);
    }

    
    public void cwe_fooSink(String data , HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        (new testset2_53c()).cwe_fooSink(data , request, response);
    }
}
