package testcases.testset2.s02;
import testcasesupport.*;

import javax.servlet.http.*;

public abstract class testset2_81_base
{
    public abstract void action(String data , HttpServletRequest request, HttpServletResponse response) throws Throwable;
}
