package testcases.testset1;

import testcasesupport.*;

import javax.servlet.http.*;

public class testset1_1_54c
{
    public void foo_barSink(String data ) throws Throwable
    {
        (new testset1_1_54d()).foo_barSink(data );
    }

    
    public void cwe_fooSink(String data ) throws Throwable
    {
        (new testset1_1_54d()).cwe_fooSink(data );
    }
}
