package testcases.testset1;

import testcasesupport.*;

import javax.servlet.http.*;

public class testset1_1_53c
{
    public void foo_barSink(String data ) throws Throwable
    {
        (new testset1_1_53d()).foo_barSink(data );
    }

    
    public void cwe_fooSink(String data ) throws Throwable
    {
        (new testset1_1_53d()).cwe_fooSink(data );
    }
}
