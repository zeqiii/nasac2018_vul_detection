package testcases.testset1;

import testcasesupport.*;

import javax.servlet.http.*;

public class testset1_1_54b
{
    public void foo_barSink(String data ) throws Throwable
    {
        (new testset1_1_54c()).foo_barSink(data );
    }

    
    public void cwe_fooSink(String data ) throws Throwable
    {
        (new testset1_1_54c()).cwe_fooSink(data );
    }
}
