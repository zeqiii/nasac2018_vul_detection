
package testcases.testset5.s01;
import testcasesupport.*;

import javax.servlet.http.*;

public class testset5_1_54d
{
    public void foo_barSink(String data ) throws Throwable
    {
        (new testset5_1_54e()).foo_barSink(data );
    }

    
    public void cwe_fooSink(String data ) throws Throwable
    {
        (new testset5_1_54e()).cwe_fooSink(data );
    }

    
    public void cwe_barSink(String data ) throws Throwable
    {
        (new testset5_1_54e()).cwe_barSink(data );
    }
}
