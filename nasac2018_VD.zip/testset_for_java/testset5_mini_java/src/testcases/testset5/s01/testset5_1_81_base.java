
package testcases.testset5.s01;
import testcasesupport.*;

import javax.servlet.http.*;

public abstract class testset5_1_81_base
{
    public abstract void action(String data ) throws Throwable;
}
