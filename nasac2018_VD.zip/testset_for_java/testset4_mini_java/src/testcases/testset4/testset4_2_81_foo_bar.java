package testcases.testset4;

import testcasesupport.*;

public class testset4_2_81_foo_bar extends testset4_2_81_base
{
    public void action(int [] data ) throws Throwable
    {

        
        IO.writeLine("" + data.length);

    }
}
