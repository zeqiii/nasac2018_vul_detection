package testcases.testset4;

import testcasesupport.*;

public class testset4_2_54b
{
    public void foo_barSink(int [] data ) throws Throwable
    {
        (new testset4_2_54c()).foo_barSink(data );
    }

    
    public void cwe_fooSink(int [] data ) throws Throwable
    {
        (new testset4_2_54c()).cwe_fooSink(data );
    }

    
    public void cwe_barSink(int [] data ) throws Throwable
    {
        (new testset4_2_54c()).cwe_barSink(data );
    }
}
