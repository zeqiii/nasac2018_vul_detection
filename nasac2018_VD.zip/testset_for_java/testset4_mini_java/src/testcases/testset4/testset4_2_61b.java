package testcases.testset4;

import testcasesupport.*;

public class testset4_2_61b
{
    public int [] foo_barSource() throws Throwable
    {
        int [] data;

        
        data = null;

        return data;
    }

    
    public int [] cwe_fooSource() throws Throwable
    {
        int [] data;

        
        data = new int[5];

        return data;
    }

    
    public int [] cwe_barSource() throws Throwable
    {
        int [] data;

        
        data = null;

        return data;
    }
}
