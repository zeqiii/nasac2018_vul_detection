package testcases.testset4;

import testcasesupport.*;

public class testset4_3_54c
{
    public void foo_barSink(String data ) throws Throwable
    {
        (new testset4_3_54d()).foo_barSink(data );
    }

    
    public void cwe_fooSink(String data ) throws Throwable
    {
        (new testset4_3_54d()).cwe_fooSink(data );
    }

    
    public void cwe_barSink(String data ) throws Throwable
    {
        (new testset4_3_54d()).cwe_barSink(data );
    }
}
