package testcases.testset4;

import testcasesupport.*;

public class testset4_3_54d
{
    public void foo_barSink(String data ) throws Throwable
    {
        (new testset4_3_54e()).foo_barSink(data );
    }

    
    public void cwe_fooSink(String data ) throws Throwable
    {
        (new testset4_3_54e()).cwe_fooSink(data );
    }

    
    public void cwe_barSink(String data ) throws Throwable
    {
        (new testset4_3_54e()).cwe_barSink(data );
    }
}
