package testcases.testset4;

import testcasesupport.*;

public class testset4_3_53b
{
    public void foo_barSink(String data ) throws Throwable
    {
        (new testset4_3_53c()).foo_barSink(data );
    }

    
    public void cwe_fooSink(String data ) throws Throwable
    {
        (new testset4_3_53c()).cwe_fooSink(data );
    }

    
    public void cwe_barSink(String data ) throws Throwable
    {
        (new testset4_3_53c()).cwe_barSink(data );
    }
}
