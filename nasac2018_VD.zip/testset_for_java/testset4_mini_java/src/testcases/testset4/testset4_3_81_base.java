package testcases.testset4;

import testcasesupport.*;

public abstract class testset4_3_81_base
{
    public abstract void action(String data ) throws Throwable;
}
