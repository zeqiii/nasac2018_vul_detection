package testcases.testset4;

import testcasesupport.*;

public class testset4_3_61b
{
    public String foo_barSource() throws Throwable
    {
        String data;

        
        data = null;

        return data;
    }

    
    public String cwe_fooSource() throws Throwable
    {
        String data;

        
        data = "This is not null";

        return data;
    }

    
    public String cwe_barSource() throws Throwable
    {
        String data;

        
        data = null;

        return data;
    }
}
