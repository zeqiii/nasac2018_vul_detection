package testcases.testset4;

import testcasesupport.*;

public class testset4_2_54c
{
    public void foo_barSink(int [] data ) throws Throwable
    {
        (new testset4_2_54d()).foo_barSink(data );
    }

    
    public void cwe_fooSink(int [] data ) throws Throwable
    {
        (new testset4_2_54d()).cwe_fooSink(data );
    }

    
    public void cwe_barSink(int [] data ) throws Throwable
    {
        (new testset4_2_54d()).cwe_barSink(data );
    }
}
