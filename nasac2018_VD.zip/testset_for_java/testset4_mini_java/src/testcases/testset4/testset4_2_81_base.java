package testcases.testset4;

import testcasesupport.*;

public abstract class testset4_2_81_base
{
    public abstract void action(int [] data ) throws Throwable;
}
